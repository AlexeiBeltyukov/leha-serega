#include "game.h"
#include "hand.h"
#include "ui.h"
#include <iostream>
using namespace std;

// ============ ПРОТИВ ДИЛЕРА ============
int playRound(Deck& deck) {
    Hand player;
    Hand dealer;

    player.add(deck.draw());
    dealer.add(deck.draw());
    player.add(deck.draw());
    dealer.add(deck.draw());

    setColor(CYAN);
    cout << "\n[ Раунд ]" << endl;
    resetColor();
    divider();

    setColor(GREEN);
    cout << "Ты:" << endl;
    resetColor();
    player.print();
    cout << endl;

    setColor(RED);
    cout << "Дилер:" << endl;
    resetColor();
    dealer.printFirst();
    cout << endl;

    while (true) {
        if (player.isBust()) {
            setColor(RED);
            cout << "\nПеребор!\n";
            resetColor();
            return -1;
        }

        setColor(YELLOW);
        cout << "z-взять  x-хватит: ";
        resetColor();
        char c;
        cin >> c;

        if (c == 'z' || c == 'Z') {
            player.add(deck.draw());
            setColor(GREEN);
            cout << "Ты:" << endl;
            resetColor();
            player.print();
            cout << endl;
        } else if (c == 'x' || c == 'X') {
            break;
        } else {
            setColor(RED);
            cout << "z или x.\n";
            resetColor();
        }
    }

    if (player.isBust()) {
        setColor(RED);
        cout << "\nПеребор!\n";
        resetColor();
        return -1;
    }

    setColor(RED);
    cout << "\nХод дилера:" << endl;
    resetColor();
    dealer.print();
    cout << endl;

    while (dealer.total() < 17) {
        dealer.add(deck.draw());
        cout << "  берёт: ";
        dealer.print();
        cout << endl;
    }

    cout << endl;
    setColor(GREEN);
    cout << "Ты:    ";
    resetColor();
    player.print();
    cout << endl;

    setColor(RED);
    cout << "Дилер: ";
    resetColor();
    dealer.print();
    cout << endl;

    int p = player.total();
    int d = dealer.total();

    cout << endl;
    if (d > 21) {
        setColor(GREEN);
        cout << "★ Дилер перебрал — ты выиграл!" << endl;
        resetColor();
        return 1;
    }
    if (p > d) {
        setColor(GREEN);
        cout << "★ Ты выиграл!" << endl;
        resetColor();
        return 1;
    }
    if (p < d) {
        setColor(RED);
        cout << "✖ Дилер выиграл." << endl;
        resetColor();
        return -1;
    }
    setColor(YELLOW);
    cout << "~ Ничья." << endl;
    resetColor();
    return 0;
}

// ============ ДУЭЛЬ ============
int playDuelRound(Deck& deck) {
    Hand p1, p2;

    p1.add(deck.draw());
    p2.add(deck.draw());
    p1.add(deck.draw());
    p2.add(deck.draw());

    // --- Игрок 1 ---
    setColor(GREEN);
    cout << "\n[ Игрок 1 ]" << endl;
    resetColor();
    p1.print();
    cout << endl;

    while (true) {
        if (p1.isBust()) {
            setColor(RED);
            cout << "\nПеребор — игрок 2 победил!\n";
            resetColor();
            return 2;
        }

        setColor(YELLOW);
        cout << "z-взять  x-хватит: ";
        resetColor();
        char c;
        cin >> c;

        if (c == 'z' || c == 'Z') {
            p1.add(deck.draw());
            setColor(GREEN);
            cout << "[ Игрок 1 ]" << endl;
            resetColor();
            p1.print();
            cout << endl;
        } else if (c == 'x' || c == 'X') {
            break;
        } else {
            setColor(RED);
            cout << "z или x.\n";
            resetColor();
        }
    }

    if (p1.isBust()) {
        setColor(RED);
        cout << "\nПеребор — игрок 2 победил!\n";
        resetColor();
        return 2;
    }

    // --- Игрок 2 ---
    setColor(CYAN);
    cout << "\n[ Игрок 2 ]" << endl;
    resetColor();
    p2.print();
    cout << endl;

    while (true) {
        if (p2.isBust()) {
            setColor(RED);
            cout << "\nПеребор — игрок 1 победил!\n";
            resetColor();
            return 1;
        }

        setColor(YELLOW);
        cout << "z-взять  x-хватит: ";
        resetColor();
        char c;
        cin >> c;

        if (c == 'z' || c == 'Z') {
            p2.add(deck.draw());
            setColor(CYAN);
            cout << "[ Игрок 2 ]" << endl;
            resetColor();
            p2.print();
            cout << endl;
        } else if (c == 'x' || c == 'X') {
            break;
        } else {
            setColor(RED);
            cout << "z или x.\n";
            resetColor();
        }
    }

    if (p2.isBust()) {
        setColor(RED);
        cout << "\nПеребор — игрок 1 победил!\n";
        resetColor();
        return 1;
    }

    // --- Сравнение ---
    cout << endl;
    divider();
    setColor(GREEN);
    cout << "Игрок 1: ";
    resetColor();
    p1.print();
    cout << endl;

    setColor(CYAN);
    cout << "Игрок 2: ";
    resetColor();
    p2.print();
    cout << endl;
    divider();

    int t1 = p1.total();
    int t2 = p2.total();

    if (t1 > t2) {
        setColor(GREEN);
        cout << "★ Победил игрок 1!" << endl;
        resetColor();
        return 1;
    }
    if (t2 > t1) {
        setColor(CYAN);
        cout << "★ Победил игрок 2!" << endl;
        resetColor();
        return 2;
    }
    setColor(YELLOW);
    cout << "~ Ничья." << endl;
    resetColor();
    return 0;
}
