#ifndef GAME_H
#define GAME_H

#include "deck.h"

int playRound(Deck& deck);
int playDuelRound(Deck& deck);

#endif
