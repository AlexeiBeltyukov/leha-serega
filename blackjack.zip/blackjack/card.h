#ifndef CARD_H
#define CARD_H

enum Suit { diamonds, heart, clubs, spades };
enum Rank {
    TWO = 2, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT,
    NINE, TEN, JACK, QUEEN, KING, ACE
};

class Card {
public:
    Suit suit;
    Rank rank;

    Card(Suit s, Rank r);
    Card();

    int points() const;

    // Цветной вывод в одну строку (K♠)
    void print() const;

    // Рамка — три части
    void printTop() const;      // +------+
    void printMiddle() const;   // | K♠   |
    void printBottom() const;   // +------+
};

#endif
