#include "card.h"
#include "ui.h"
#include <iostream>
using namespace std;

Card::Card(Suit s, Rank r) : suit(s), rank(r) {}
Card::Card() : suit(diamonds), rank(TWO) {}

int Card::points() const {
    if (rank == ACE) return 11;
    if (rank >= JACK) return 10;
    return (int)rank;
}

// ============ Цветной вывод одной строкой ============
void Card::print() const {
    if (suit == heart || suit == diamonds) setColor(RED);
    else setColor(WHITE);

    switch (rank) {
        case JACK:  cout << "J"; break;
        case QUEEN: cout << "Q"; break;
        case KING:  cout << "K"; break;
        case ACE:   cout << "A"; break;
        default:    cout << (int)rank;
    }
    switch (suit) {
        case diamonds: cout << "♦"; break;
        case heart:    cout << "♥"; break;
        case clubs:    cout << "♣"; break;
        case spades:   cout << "♠"; break;
    }

    resetColor();
}

// ============ Верхняя рамка ============
void Card::printTop() const {
    cout << "+------+";
}

// ============ Середина: | K♠   | ============
void Card::printMiddle() const {
    if (suit == heart || suit == diamonds) setColor(RED);
    else setColor(WHITE);

    cout << "| ";

    int rlen = 1;
    switch (rank) {
        case JACK:  cout << "J"; break;
        case QUEEN: cout << "Q"; break;
        case KING:  cout << "K"; break;
        case ACE:   cout << "A"; break;
        case TEN:   cout << "10"; rlen = 2; break;
        default:    cout << (int)rank;
    }

    switch (suit) {
        case diamonds: cout << "♦"; break;
        case heart:    cout << "♥"; break;
        case clubs:    cout << "♣"; break;
        case spades:   cout << "♠"; break;
    }

    for (int i = rlen + 1; i < 4; ++i) cout << " ";
    cout << " |";

    resetColor();
}

// ============ Нижняя рамка ============
void Card::printBottom() const {
    cout << "+------+";
}
