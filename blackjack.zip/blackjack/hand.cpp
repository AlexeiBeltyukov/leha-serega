#include "hand.h"
#include "ui.h"
#include <iostream>
using namespace std;

Hand::Hand() : count(0) {}

void Hand::add(const Card& c) {
    if (count < 12) {
        cards[count] = c;
        count++;
    }
}

int Hand::total() const {
    int sum = 0;
    int aces = 0;

    for (int i = 0; i < count; ++i) {
        sum += cards[i].points();
        if (cards[i].rank == ACE) aces++;
    }

    while (sum > 21 && aces > 0) {
        sum -= 10;
        aces--;
    }

    return sum;
}

bool Hand::isBust() const {
    return total() > 21;
}

// ============ Вывод руки в рамках ============
void Hand::print() const {
    if (count == 0) {
        cout << "(пусто)";
        return;
    }

    // Верхняя линия
    for (int i = 0; i < count; ++i) {
        cards[i].printTop();
        if (i < count - 1) cout << " ";
    }
    cout << endl;

    // Середина
    for (int i = 0; i < count; ++i) {
        cards[i].printMiddle();
        if (i < count - 1) cout << " ";
    }
    cout << endl;

    // Нижняя линия
    for (int i = 0; i < count; ++i) {
        cards[i].printBottom();
        if (i < count - 1) cout << " ";
    }
    cout << endl;

    setColor(YELLOW);
    cout << "(очков: " << total() << ")";
    resetColor();
}

// ============ Первая карта дилера + [скрыта] ============
void Hand::printFirst() const {
    if (count == 0) return;

    cards[0].printTop();
    cout << endl;
    cards[0].printMiddle();
    cout << endl;
    cards[0].printBottom();

    setColor(GRAY);
    cout << " [скрыта]";
    resetColor();
}
