#include <iostream>
#include <windows.h>
#include <string>
#include "rng.h"
#include "game.h"
#include "ui.h"
using namespace std;

// Удалить предмет по индексу
void removeItem(string* items, int& count, int index) {
    for (int i = index; i < count - 1; ++i) {
        items[i] = items[i + 1];
    }
    count--;
}

// Добавить предмет
void addItem(string* items, int& count, string name) {
    if (count < 10) {
        items[count] = name;
        count++;
    }
}

// ============ РЕЖИМ 1: ПРОТИВ ДИЛЕРА ============
void playVsDealer() {
    // Настройка предметов
    int itemCount;
    setColor(GREEN);
    cout << "\n[ Настройка ]" << endl;
    resetColor();
    cout << "Сколько предметов (0-10): ";
    cin >> itemCount;

    if (itemCount < 0) itemCount = 0;
    if (itemCount > 10) itemCount = 10;

    string items[10];
    cin.ignore();

    for (int i = 0; i < itemCount; ++i) {
        setColor(YELLOW);
        cout << "  Предмет " << i + 1 << ": ";
        resetColor();
        getline(cin, items[i]);
        if (items[i].empty()) {
            items[i] = "предмет" + to_string(i + 1);
        }
    }

    Deck deck;
    deck.shuffle();

    int money = 100;
    int wins = 0, losses = 0, draws = 0;

    while (true) {
        if (deck.size() < 10) {
            setColor(CYAN);
            cout << "\n(перетасовка)\n";
            resetColor();
            deck = Deck();
            deck.shuffle();
        }

        // Ресурсы
        divider();
        setColor(YELLOW);
        cout << "[ Дилер ]  " << money << " монет" << endl;
        cout << "Предметы:  " << itemCount;
        if (itemCount > 0) {
            cout << " (";
            for (int i = 0; i < itemCount; ++i) {
                cout << items[i];
                if (i < itemCount - 1) cout << ", ";
            }
            cout << ")";
        }
        cout << endl;
        resetColor();
        divider();

        if (money <= 0 && itemCount <= 0) {
            setColor(RED);
            cout << "\nВсё кончилось.\n";
            resetColor();
            break;
        }

        // Меню ставки
        int betType;
        setColor(GREEN);
        cout << "Чем играем?" << endl;
        resetColor();
        if (money > 0)     cout << "  1. Деньги\n";
        if (itemCount > 0) cout << "  2. Предмет\n";
        cout << "  3. Новый предмет\n";
        cout << "  0. Выход\n";
        setColor(YELLOW);
        cout << "> ";
        resetColor();
        cin >> betType;

        if (betType == 0) break;

        int result = 0;

        // --- Деньги ---
        if (betType == 1) {
            if (money <= 0) {
                setColor(RED);
                cout << "Нет денег.\n";
                resetColor();
                continue;
            }
            int bet;
            setColor(GREEN);
            cout << "Ставка (1-" << money << "): ";
            resetColor();
            cin >> bet;
            if (bet < 1 || bet > money) {
                setColor(RED);
                cout << "Неверно.\n";
                resetColor();
                continue;
            }

            result = playRound(deck);
            if (result == 1) { money += bet; wins++; }
            else if (result == -1) { money -= bet; losses++; }
            else draws++;
        }
        // --- Предмет из рюкзака ---
        else if (betType == 2) {
            if (itemCount <= 0) {
                setColor(RED);
                cout << "Нет предметов.\n";
                resetColor();
                continue;
            }

            setColor(GREEN);
            cout << "Какой?" << endl;
            resetColor();
            for (int i = 0; i < itemCount; ++i) {
                cout << "  " << i + 1 << ". " << items[i] << endl;
            }
            setColor(YELLOW);
            cout << "> ";
            resetColor();
            int num;
            cin >> num;

            if (num < 1 || num > itemCount) {
                setColor(RED);
                cout << "Неверно.\n";
                resetColor();
                continue;
            }

            int idx = num - 1;
            result = playRound(deck);

            if (result == 1) {
                money += 50;
                wins++;
                setColor(GREEN);
                cout << "\n★ Предмет сохранён! +50 монет\n";
                resetColor();
            } else if (result == -1) {
                string lost = items[idx];
                removeItem(items, itemCount, idx);
                losses++;
                setColor(RED);
                cout << "\n✖ Потерян: " << lost << endl;
                resetColor();
            } else {
                draws++;
                setColor(YELLOW);
                cout << "\n~ Ничья — предмет остаётся.\n";
                resetColor();
            }
        }
        // --- Новый предмет ---
        else if (betType == 3) {
            setColor(GREEN);
            cout << "Название: ";
            resetColor();
            cin.ignore();
            string newItem;
            getline(cin, newItem);

            if (newItem.empty()) {
                setColor(RED);
                cout << "Пусто.\n";
                resetColor();
                continue;
            }

            result = playRound(deck);

            if (result == 1) {
                addItem(items, itemCount, newItem);
                money += 50;
                wins++;
                setColor(GREEN);
                cout << "\n★ " << newItem << " — в рюкзак! +50 монет\n";
                resetColor();
            } else if (result == -1) {
                losses++;
                setColor(RED);
                cout << "\n✖ Потерян: " << newItem << endl;
                resetColor();
            } else {
                addItem(items, itemCount, newItem);
                draws++;
                setColor(YELLOW);
                cout << "\n~ Ничья — " << newItem << " остаётся.\n";
                resetColor();
            }
        }
        else {
            setColor(RED);
            cout << "Неверно.\n";
            resetColor();
            continue;
        }

        setColor(GREEN);
        cout << "Ещё? (y/n): ";
        resetColor();
        char c;
        cin >> c;
        if (c != 'y' && c != 'Y') break;
    }

    divider();
    setColor(YELLOW);
    cout << "Итог: " << money << " монет, " << itemCount << " предметов";
    cout << "  (П:" << wins << " Пр:" << losses << " Н:" << draws << ")" << endl;
    resetColor();
}

// ============ РЕЖИМ 2: ДУЭЛЬ ============
void playDuel() {
    Deck deck;
    deck.shuffle();

    string n1, n2;
    cin.ignore();

    setColor(GREEN);
    cout << "\n[ Игрок 1 ]" << endl;
    resetColor();
    cout << "Имя: ";
    getline(cin, n1);
    if (n1.empty()) n1 = "Игрок 1";

    setColor(CYAN);
    cout << "\n[ Игрок 2 ]" << endl;
    resetColor();
    cout << "Имя: ";
    getline(cin, n2);
    if (n2.empty()) n2 = "Игрок 2";

    int m1 = 100, m2 = 100;

    while (true) {
        if (deck.size() < 10) {
            setColor(CYAN);
            cout << "\n(перетасовка)\n";
            resetColor();
            deck = Deck();
            deck.shuffle();
        }

        divider();
        setColor(GREEN);
        cout << n1 << ": " << m1 << " монет" << endl;
        resetColor();
        setColor(CYAN);
        cout << n2 << ": " << m2 << " монет" << endl;
        resetColor();
        divider();

        if (m1 <= 0 || m2 <= 0) {
            setColor(RED);
            cout << "\nДеньги кончились у одного из игроков.\n";
            resetColor();
            break;
        }

        int maxBet = (m1 < m2) ? m1 : m2;

        int bet;
        setColor(YELLOW);
        cout << "Ставка (1-" << maxBet << ", 0 - выход): ";
        resetColor();
        cin >> bet;

        if (bet == 0) break;
        if (bet < 1 || bet > maxBet) {
            setColor(RED);
            cout << "Неверно.\n";
            resetColor();
            continue;
        }

        int result = playDuelRound(deck);

        if (result == 1) {
            m1 += bet; m2 -= bet;
            setColor(GREEN);
            cout << "\n★ " << n1 << " забирает " << bet << " монет!" << endl;
            resetColor();
        } else if (result == 2) {
            m2 += bet; m1 -= bet;
            setColor(CYAN);
            cout << "\n★ " << n2 << " забирает " << bet << " монет!" << endl;
            resetColor();
        } else {
            setColor(YELLOW);
            cout << "\n~ Ничья." << endl;
            resetColor();
        }

        setColor(GREEN);
        cout << "Ещё? (y/n): ";
        resetColor();
        char c;
        cin >> c;
        if (c != 'y' && c != 'Y') break;
    }

    divider();
    setColor(GREEN);
    cout << n1 << ": " << m1 << " монет" << endl;
    resetColor();
    setColor(CYAN);
    cout << n2 << ": " << m2 << " монет" << endl;
    resetColor();
    divider();

    setColor(MAGENTA);
    if (m1 > m2) cout << "★ Победитель: " << n1 << endl;
    else if (m2 > m1) cout << "★ Победитель: " << n2 << endl;
    else cout << "~ Ничья." << endl;
    resetColor();
}

// ============ MAIN ============
int main() {
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);

    setColor(CYAN);
    cout << "\n<< БЛЭКДЖЕК >>" << endl;
    resetColor();

    setColor(YELLOW);
    cout << "Случайное число: ";
    resetColor();
    unsigned int s;
    cin >> s;
    setSeed(s);

    while (true) {
        divider();
        setColor(CYAN);
        cout << "[ Режим ]" << endl;
        resetColor();
        setColor(GREEN);
        cout << "  1. Против дилера" << endl;
        resetColor();
        setColor(CYAN);
        cout << "  2. Дуэль" << endl;
        resetColor();
        cout << "  0. Выход" << endl;

        setColor(YELLOW);
        cout << "> ";
        resetColor();
        int mode;
        cin >> mode;

        if (mode == 0) break;

        if (mode == 1) playVsDealer();
        else if (mode == 2) playDuel();
        else {
            setColor(RED);
            cout << "Неверно.\n";
            resetColor();
        }
    }

    setColor(CYAN);
    cout << "\nПока!\n" << endl;
    resetColor();
    return 0;
}
