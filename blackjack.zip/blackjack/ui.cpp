#include "ui.h"
#include <iostream>
#include <windows.h>
using namespace std;

void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void resetColor() {
    setColor(WHITE);
}

void divider() {
    setColor(GRAY);
    for (int i = 0; i < 40; ++i) cout << '-';
    cout << endl;
    resetColor();
}
